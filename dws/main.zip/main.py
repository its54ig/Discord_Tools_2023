from flask import Flask, render_template, request
from markupsafe import Markup
import requests

app = Flask(__name__)

token = "NzY5MTU2Mjk1MDkyODYzMDQ2.G4Cxkd.eEthPJHnnI7VmL5tjkIgrZexpWvifgI3lkimH8"


@app.route("/")
def redirect():
    return render_template("redirect.html")


@app.route("/home")
def home():
    guilds = requests.get(
        url="https://discord.com/api/v9/users/@me/guilds",
        headers={
            "Authorization": token
        }
    ).json()

    html_data = ""

    for i in guilds:
        html_data += f"<button onclick=\"window.location.replace(\'/guild?id={i['id']}\')\" class=\"guild-button\"><img src=\"https://cdn.discordapp.com/icons/{i['id']}/{i['icon']}?size=512\" width=\"256\" height=\"256\"><h3>{i['name']}</h3></button>"

    return render_template("homepage.html", data=Markup(html_data))


@app.route("/guild")
def guild():
    guild = requests.get(
        url=f"https://discord.com/api/v9/guilds/{request.args['id']}",
        headers={
            "Authorization": token
        }
    ).json()
    
    owner = requests.get(
        url=f"https://discord.com/api/v9/users/{guild['owner_id']}",
        headers={
            "Authorization": token
        }
    ).json()

    channels = requests.get(
        url=f"https://discord.com/api/v9/guilds/{guild['id']}/channels",
        headers={
            "Authorization": token
        }
    ).json()

    data = {
        "name": guild["name"],
        "server_icon": f"https://cdn.discordapp.com/icons/{guild['id']}/{guild['icon']}?size=1024",
        "owner_avatar": f"https://cdn.discordapp.com/avatars/{owner['id']}/{owner['avatar']}?size1024",
        "guild": guild,
        "owner": owner,
        "channel_list": "<b>e</b>"
    }

    print(request.args['id'])

    # for i in channels:
        # data["channel_list"] += f"<a href=\"/channel?guild={guild['id']}&channel={i['id']}\">{i['name']} ({i['id']})</a>"
    
    print(data['channel_list'])

    return render_template("guild.html", plain_text=data)


@app.route("/channels")
def channels():
    pass


@app.route("/example")
def example():
    # meant for testing...
    return requests.get(
        url=f"https://discord.com/api/v9/guilds/1151402600219037736/channels",
        headers={
            "Authorization": token
        }
    ).json()


app.run(use_reloader=True)